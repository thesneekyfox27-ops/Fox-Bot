# NBHD Rooms v3.3.0

Motel room system for QBCore, configured through `Config.Buildings` in `config.lua`.

## What changed in v3
- **Safes are back in every room.** All 48 rooms get a safe at the exact spot set in the config (6 floors x 8 rooms).
  - Safes only spawn while you are near the building (`Config.SpawnDistance`), once the floors have loaded. Before, they spawned at login and fell under the map.
  - Any safe that goes missing is respawned every 2 seconds while you are nearby.
  - Safes sit on the floor based on the model's real size. Use `safeLift` to nudge them up or down.
- **Your safe storage is yours.** The stash id is `<building>_locker_<citizenid>`, the same id as before, so nothing already stored is lost. It follows you even if you get a different room.
- **Same room back.** With `Config.KeepLastRoom = true` you get your last room back on login, as long as nobody else has taken it.
- **Front desk.** Press E at the receptionist to get a key card showing your room, floor and name. The floor is worked out from 8 rooms per floor:

| Floor | Rooms |
|------|-------|
| 1 | 1-8 |
| 2 | 9-16 |
| 3 | 17-24 |
| 4 | 25-32 |
| 5 | 33-40 |
| 6 | 41-48 |

  If your building counts the lobby as Floor 1, set `floorOffset = 1` so rooms 1-8 show as "Floor 2".
- **Server checks.** You can only lock or unlock your own door, standing at it (3 m). You can only open your own room's safe, standing at it. The front desk only answers when you are at the desk.
- **Inventory is detected automatically** (`Config.Inventory = 'auto'`): tgiann-inventory, then ox_inventory, then qb-inventory, then the old client event.
- **Wardrobe** (17mov_CharacterSystem) uses the same events as nrp-clothingstore. Press E and choose **Change clothes** (full editor) or **My saved outfits**.
  Change `Config.Wardrobe.mode` to `'editor'` or `'outfits'` to skip the choice.
- **Dressing room.** "Change clothes" fades you to a roomy, well-lit spot so the editor camera can see you. The default is 17mov's own creator point.
  You go into your own private world (nobody sees you, no NPCs) at midday, and when you Save or Cancel you're put back exactly where you stood in your room.
  If you crash while dressing, your saved position is set back to your room. Configure it under `Config.Wardrobe.dressingRoom`.
- **Homeowners** listed in `Config.HomeTables` (qb-houses / ps-housing) are not given a room automatically. Tables that don't exist are ignored.
- **New UI:** door, safe, wardrobe and front desk panels. The front desk hands you a beach "welcome" key card with a paper sleeve showing your room, floor, name and "Take the elevator to Floor N".

## Commands
- `/myroom`: your room, floor, door distance, lock state and whether your safe is spawned (F8)
- `/deskped`: shows where the front desk girl is (F8) and respawns her
- `/roomfloors`: prints which rooms are on which floor (F8)
- `/finddoor`: lists objects within 3 m (for finding door models)

## Install
Replace the whole folder, run `refresh`, then `ensure nbhd_rooms`.
The database tables (`nbhd_rooms`, `nbhd_rooms_last`) are created automatically.
